package ma.permis.maroc

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
