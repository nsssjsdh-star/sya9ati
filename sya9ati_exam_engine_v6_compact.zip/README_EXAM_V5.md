# Sya9ati – Exam Engine V5

This version rebuilds the exam mechanism based on structural observations from the supplied reference APK, without copying its proprietary question bank or media files.

## Mechanism implemented
- Series selector with 42 series.
- Each series launches 40 questions.
- 30-minute countdown for B simulation.
- Multiple correct answers supported (e.g. answer codes such as 12, 13, 23).
- Four numbered choices (1/2/3/4).
- Question media slots: image 1, image 2, optional audio field in the data model.
- No answer explanation during the B simulation; result is shown at the end.
- Wrong-answer tracking and score persistence.
- TTS button for reading the current question.
- Original road-scene SVG illustrations are bundled as placeholders so the media mechanism is testable without copying media from the reference APK.

## Important content note
The current question bank is still the project's training bank. It is NOT presented as an official NARSA question bank. NARSA states that the theoretical B exam automatically selects 40 questions from its information system and that the passing threshold is 32/40.

The next content phase should replace the training questions with content that we have a legitimate source/permission to use.
