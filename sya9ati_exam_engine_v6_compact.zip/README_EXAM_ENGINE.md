# Sya9ati — Exam Engine update

This version redesigns the exam flow after inspecting the supplied `Siya9a Maroc 2026.apk` reference application.

## Reference mechanics observed
- Quiz data is organized into series of 40 questions.
- The reference database contains 42 series (30 code, 2 mechanics, 10 Narsa-Perminou).
- Each quiz row stores up to two visual frames, optional media/audio, an explanation, and an answer code.
- Answer codes can contain multiple digits (`1`, `12`, `123`, etc.), which means a question may have more than one correct choice.
- The exam therefore needs multi-select answers rather than the previous single-radio-answer behavior.

## Implemented in Sya9ati
- Four numbered choices: 1 / 2 / 3 / 4.
- Multiple answers can be selected.
- Exact-set validation: all correct choices must be selected and no incorrect choice selected.
- 40-question exam mode with a 30-minute timer.
- During the exam, correct answers are not revealed immediately.
- Training mode can show the correction/explanation after confirmation.
- Question model now supports optional image 1, image 2, audio asset, and multi-answer codes for future official/authorized content import.
- Existing sign assets and Android build configuration were kept intact.

## Important
The reference APK's question media files are not bundled in the supplied APK; the database contains filenames for them. This update copies the **interaction/data mechanism**, not the reference app's proprietary code or media.
