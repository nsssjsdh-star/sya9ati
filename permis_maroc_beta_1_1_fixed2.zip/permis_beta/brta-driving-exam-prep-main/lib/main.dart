import 'dart:math';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  runApp(PermisMarocApp(prefs: prefs));
}

class Question {
  final String id, category, text, explanation;
  final List<String> options;
  final int answer;
  const Question({required this.id, required this.category, required this.text, required this.options, required this.answer, required this.explanation});
}

class RoadSign {
  final String title, group, meaning, action, symbol;
  const RoadSign(this.title, this.group, this.meaning, this.action, this.symbol);
}

const categories = <String>['قواعد الطريق','علامات التشوير','السائق','المركبة','المخالفات','السلامة'];

const questions = <Question>[
  Question(id:'q01',category:'قواعد الطريق',text:'إلى وصلتي لتقاطع وما كاين لا ضو لا علامة ديال الأسبقية، شنو خاصك تدير؟',options:['تسرّع باش تدوز قبل الآخرين','تبقى مركز وتشوف شكون عندو الأسبقية قبل ما تدخل','توقف ديما حتى إلا كانت الطريق خاوية','تستعمل الكلاكسون وتدوز'],answer:1,explanation:'ما تدخلش للتقاطع حتى تتأكد من وضعية الطريق والأسبقية، وخاصك تبقى واجد لأي خطر.'),
  Question(id:'q02',category:'قواعد الطريق',text:'إلى كان الضوء الأحمر شاعل، شنو كتدير؟',options:['كتدوز إلا ما كان حتى واحد','كتوقف قبل خط الوقوف إلا كان موجود','كتسرّع باش ما تعطلش','كتبدل المسار وكتدوز'],answer:1,explanation:'الضوء الأحمر كيعني خاصك توقف وتحترم الإشارة.'),
  Question(id:'q03',category:'علامات التشوير',text:'علامة STOP كتطلب منك شنو؟',options:['تنقص السرعة غير شوية','توقف كامل وتتأكد قبل ما تكمل','تدوز بسرعة','توقف غير فالليل'],answer:1,explanation:'علامة قف كتفرض الوقوف، ومن بعد كتقدر تكمل ملي تتأكد بلي الطريق آمنة.'),
  Question(id:'q04',category:'السلامة',text:'علاش خاصك تخلي مسافة أمان مع السيارة اللي قدامك؟',options:['باش تبدل المسار بسهولة','باش يكون عندك الوقت والمسافة باش تفرمل إلا وقع شي خطر','باش تمشي أسرع','باش ما يشوفكش الرادار'],answer:1,explanation:'مسافة الأمان كتعاونك تتصرف إلا السيارة اللي قدامك فرملات فجأة.'),
  Question(id:'q05',category:'السائق',text:'إلى حسّيتي براسك نعسان وانت سايق، شنو هو التصرف الآمن؟',options:['تحل الشرجم وتكمل','ترفع الموسيقى وتكمل','توقف فبلاصة آمنة وترتاح','تزيد السرعة باش توصل بكري'],answer:2,explanation:'النعاس كيهبط التركيز ورد الفعل. أحسن حل هو توقف فبلاصة آمنة وترتاح.'),
  Question(id:'q06',category:'السائق',text:'استعمال الهاتف باليد وانت سايق يقدر يدير شنو؟',options:['يزيد التركيز','يشتت الانتباه ويأخر رد الفعل','ما عندو حتى تأثير','كيعاونك تشوف الطريق'],answer:1,explanation:'الهاتف كيشتت الانتباه وكيقدر يخليك ما تنتبهش للخطر فالوقت المناسب.'),
  Question(id:'q07',category:'المركبة',text:'قبل ما تنطلق، شنو من الحوايج اللي خاصك تضبط وتتأكد منهم؟',options:['غير الراديو','الكرسي والمرايات والحزام وحالة السيارة','لون السيارة','الهاتف'],answer:1,explanation:'قبل الانطلاق خاص وضعية السياقة تكون مريحة وآمنة، والمرايات والحزام يكونو مضبوطين.'),
  Question(id:'q08',category:'علامات التشوير',text:'علامة مثلثة بحافة حمراء كتكون غالباً شنو؟',options:['علامة كتنبّه لخطر','علامة موقف','علامة خدمات','علامة نهاية الطريق'],answer:0,explanation:'الشكل المثلث بحافة حمراء كيستعمل للتحذير من الأخطار حسب الرمز اللي فالداخل.'),
  Question(id:'q09',category:'قواعد الطريق',text:'إلى بغيتي تبدل المسار، شنو خاصك تدير قبل المناورة؟',options:['تدخل مباشرة','تشوف المرايات والنقطة اللي ما كتبانش، تعطي الإشارة وتتأكد','توقف وسط الطريق','تستعمل الكلاكسون فقط'],answer:1,explanation:'خاصك تراقب المرايات، تتأكد من النقطة اللي ما كتبانش، تعطي الإشارة ومن بعد تبدل المسار إلا كان آمن.'),
  Question(id:'q10',category:'السلامة',text:'حزام السلامة شنو الدور ديالو؟',options:['غير كيخلي السائق مرتاح','كيحمي السائق والركاب فحالة صدمة','كيزيد سرعة السيارة','ما عندوش دور داخل المدينة'],answer:1,explanation:'الحزام كينقص من خطر الإصابة وكيعاون يبقى الشخص فمكانو فحالة صدمة.'),
  Question(id:'q11',category:'قواعد الطريق',text:'فاش كتقرب من ممر الراجلين، شنو خاصك تدير؟',options:['تسرّع','تنقص السرعة وتبقى واجد توقف','تستعمل الكلاكسون باش يهربو','دوز بلا ما تشوف'],answer:1,explanation:'خاصك تنتبه للراجلين، تنقص السرعة وتكون واجد توقف حسب الوضعية والتشوير.'),
  Question(id:'q12',category:'السائق',text:'السياقة تحت تأثير الكحول كتأثر على شنو؟',options:['التركيز ورد الفعل','لون السيارة','ضغط العجلات فقط','ما كتأثرش'],answer:0,explanation:'الكحول كيأثر على التركيز والحكم على السرعة والمسافة ورد الفعل، وكيزيد خطر الحوادث.'),
  Question(id:'q13',category:'المركبة',text:'إلى بان ليك ضو تحذيري مهم فالطابلو، شنو الأفضل؟',options:['تتجاهلو','توقف بأمان إلا كان كاين خطر وتراجع دليل السيارة','تزيد السرعة','تطفي جميع الأضواء'],answer:1,explanation:'ضو التحذير ممكن يكون كيشير لمشكل خاصو الانتباه. إلا كان الخطر مهم، وقف فبلاصة آمنة.'),
  Question(id:'q14',category:'قواعد الطريق',text:'فالتجاوز، شنو أهم حاجة؟',options:['التجاوز بأي ثمن','تتأكد بلي التجاوز مسموح وآمن والرؤية كافية','تتجاوز فالمنعرج بلا رؤية','تستعمل الهاتف أثناء التجاوز'],answer:1,explanation:'التجاوز خاصو يكون مسموح وآمن، مع رؤية ومسافة كافيين وما يكونش خطر على الآخرين.'),
  Question(id:'q15',category:'السلامة',text:'إلى كانت الطريق مبللة، شنو كيقدر يوقع لمسافة الفرملة؟',options:['كتنقص','كتقدر تزيد','كتبقى ديما نفسها','كتولي صفر'],answer:1,explanation:'الطريق المبللة كتقدر تنقص التماسك وتزيد مسافة الفرملة، لذلك خاص تخفيف السرعة والحذر.'),
  Question(id:'q16',category:'قواعد الطريق',text:'شنو خاصك تدير ملي كتشوف الضوء الأصفر؟',options:['تتعامل معاه بحال الأخضر ديما','تبقى مركز وتكون واجد توقف حسب الوضعية','ترجع للور','تطفي الأضواء'],answer:1,explanation:'الضوء الأصفر كيتطلب الانتباه والاستعداد للتوقف حسب الحالة، وماشي إشارة باش تسرّع.'),
  Question(id:'q17',category:'علامات التشوير',text:'إلى كانت علامة كتمنع اتجاه معين، شنو خاصك تدير؟',options:['تتجاهلها','تحترم المنع وتختار اتجاه مسموح','تدوز فالليل فقط','توقف وسط الطريق'],answer:1,explanation:'علامات المنع خاصها الاحترام، وخصك تختار المسار اللي مسموح ليك.'),
  Question(id:'q18',category:'المركبة',text:'ضغط العجلات إلا ما كانش مناسب يقدر يأثر على شنو؟',options:['التحكم والتماسك والاستهلاك','لون السيارة فقط','الراديو','المصابيح الداخلية فقط'],answer:0,explanation:'ضغط العجلات كيأثر على التماسك والتحكم فالسيارة والفرملة وحتى الاستهلاك.'),
  Question(id:'q19',category:'السائق',text:'إلى كنت غاضب بزاف وانت سايق، شنو الأفضل؟',options:['تزيد السرعة','تحاول تهدأ وتتجنب القرارات الخطيرة','تستعمل الكلاكسون باستمرار','تسوق بلا ما تشوف المرايات'],answer:1,explanation:'الغضب والتوتر كيقدرو يأثرو على التركيز والقرارات. الهدوء كيساعد على السياقة الآمنة.'),
  Question(id:'q20',category:'السلامة',text:'فالليل، شنو خاصك تراقب أكثر؟',options:['غير لون الطريق','الرؤية والأضواء والسرعة والمستعملين الآخرين','الهاتف','الراديو'],answer:1,explanation:'فالليل الرؤية كتكون محدودة، لذلك خاصك تضبط السرعة وتستعمل الأضواء بطريقة صحيحة وتبقى مركز.'),
  Question(id:'q21',category:'قواعد الطريق',text:'إلى كان عون مكلف بتنظيم السير كيعطيك تعليمات، شنو كتدير؟',options:['كتتبع الضوء فقط','كتحترم تعليماتو فالحين','كتشوف شنو غادي تدير السيارة اللي وراك','كتستعمل الهاتف'],answer:1,explanation:'تعليمات العون المكلف بتنظيم السير خاصها الاحترام، وكتوجه حركة السير فداك الوقت.'),
  Question(id:'q22',category:'علامات التشوير',text:'علامة دائرية زرقاء فيها سهم كتدل غالباً على شنو؟',options:['إلزام باتجاه معين حسب الرمز','خطر فقط','منع دائماً','موقف ممنوع دائماً'],answer:0,explanation:'العلامات الدائرية الزرقاء اللي فيها سهم كتستعمل للإلزام باتجاه معين حسب الرمز.'),
  Question(id:'q23',category:'المركبة',text:'علاش خاصك تضبط المرايات قبل الانطلاق؟',options:['باش تزين السيارة','باش توسع مجال الرؤية وتنقص المناطق اللي ما كتبانش','باش تزيد السرعة','باش ينقص استهلاك الوقود فقط'],answer:1,explanation:'ضبط المرايات كيساعدك تشوف اللي وراك وحذاك بشكل أحسن قبل المناورات.'),
  Question(id:'q24',category:'قواعد الطريق',text:'إلى بغيتي تدير انعطاف، شنو خاصك تدير؟',options:['تعطي الإشارة وتراقب الطريق وتدخل بأمان','تنعطف فجأة','تستعمل الهاتف','تطفي الأضواء'],answer:0,explanation:'خاص الإشارة والمراقبة والتأكد من السلامة قبل الانعطاف، مع احترام التشوير.'),
  Question(id:'q25',category:'السلامة',text:'شنو كيقدر يزيد خطر الحادث فالطريق؟',options:['السرعة غير المناسبة وقلة الانتباه','التركيز','مسافة الأمان','احترام التشوير'],answer:0,explanation:'السرعة غير المناسبة والتشتت من عوامل الخطر، بينما التركيز واحترام القواعد كينقصو الخطر.'),
  Question(id:'q26',category:'المخالفات',text:'علاش خاص السائق يحترم التشوير الطرقي؟',options:['حيت غير نصيحة','حيت كينظم السير وكيحمي مستعملي الطريق','باش يربح الوقت','باش السيارة تبان زوينة'],answer:1,explanation:'التشوير كينظم حركة السير وكيعطي تعليمات وتحذيرات خاص مستعملي الطريق يحترموها.'),
  Question(id:'q27',category:'المركبة',text:'إلى كانت الأضواء الأمامية موسخة، شنو المشكل؟',options:['كتزيد الرؤية','كتنقص فعالية الإنارة والرؤية','ما كتأثرش','كتزيد قوة المحرك'],answer:1,explanation:'الأوساخ كتقدر تنقص من قوة ووضوح الإضاءة، خصوصاً فالليل والطقس الخايب.'),
  Question(id:'q28',category:'السائق',text:'إلى كنت كتستعمل شي دوا، شنو خاصك تنتبه ليه؟',options:['غير اللون ديالو','واش كيأثر على اليقظة والسياقة حسب الإرشادات','تزيد الجرعة','ماشي مهم'],answer:1,explanation:'كاين أدوية كتقدر تأثر على اليقظة ورد الفعل. خاص تتبع الإرشادات اللي مع الدوا وتسول المختص إلا كان الشك.'),
  Question(id:'q29',category:'قواعد الطريق',text:'فالمنعرج اللي ما كتشوفش من وراه، التجاوز كيكون؟',options:['مناورة عادية','خطير وقد يكون ممنوع حسب التشوير والقواعد','واجب','أحسن وقت للتجاوز'],answer:1,explanation:'قلة الرؤية كتخلي التجاوز خطر، وخص احترام الحالات اللي كتمنع فيها هاد المناورة.'),
  Question(id:'q30',category:'السلامة',text:'شنو كتدير ملي كتسوق فالمطر القوي؟',options:['تزيد السرعة','تنقص السرعة وتزيد الحذر وتخلي مسافة أمان أكبر','تطفي الأضواء','تلصق فالسيارة اللي قدامك'],answer:1,explanation:'المطر القوي كيهبط الرؤية والتماسك، لذلك خاص تخفيف السرعة وزيادة مسافة الأمان.'),
  Question(id:'q31',category:'قواعد الطريق',text:'إلى كانت علامة كتفرض عليك اتجاه معين، واش تقدر تختار اتجاه آخر؟',options:['إيلا كان الطريق خاوي','لا، إلا كان المنع أو الإلزام كينطبق خاصك تحترمو','غير فالليل','غير إلا كنت مستعجل'],answer:1,explanation:'خاص احترام الإلزام والمنع اللي كيبينو التشوير فالطريق.'),
  Question(id:'q32',category:'السلامة',text:'إلى لقيتي عائق قدامك، شنو التصرف الآمن؟',options:['تتجاهلو','تنقص السرعة وتبدل الاتجاه غير من بعد ما تتأكد من السلامة','تسرّع نحوه','تغمض عينيك'],answer:1,explanation:'خاصك تكتشف العائق بكري، تنقص السرعة وتتأكد من الطريق قبل أي مناورة.'),
  Question(id:'q33',category:'علامات التشوير',text:'علامة نهاية منع معين كتدل على شنو؟',options:['بداية منع جديد ديما','نهاية المنع اللي كتشير ليه العلامة','STOP','طريق مسدود ديما'],answer:1,explanation:'علامة نهاية المنع كتعلن نهاية المنع المعني بها حسب الرمز.'),
  Question(id:'q34',category:'السلامة',text:'شنو كتدير إذا السيارة اللي قدامك فرملات فجأة؟',options:['تلصق فيها','تفرمل وتحافظ على التحكم وتحاول تتصرف بلا مناورة خطيرة','تستعمل الهاتف','تغمض عينيك'],answer:1,explanation:'مسافة الأمان كتخليك يكون عندك وقت للتصرف. حافظ على التحكم وما تديرش مناورة خطيرة بلا ما تتأكد.'),
  Question(id:'q35',category:'السائق',text:'التركيز أثناء السياقة كيعني شنو؟',options:['تبقى تابع الطريق والمحيط ديالك باستمرار','تشوف الهاتف','تسوق بلا مرايات','تتكلم بلا توقف'],answer:0,explanation:'السائق خاصو يبقى واعي بالطريق والإشارات والسيارات والراجلين والمخاطر اللي ممكن تظهر.'),
  Question(id:'q36',category:'قواعد الطريق',text:'إلى بغيتي توقف، شنو خاصك تراعي؟',options:['أي بلاصة','واش الوقوف مسموح وما كيعرقلش السير وما كيخلقش خطر','وسط التقاطع','فممر الراجلين'],answer:1,explanation:'الوقوف والتوقف عندهم شروط وأماكن ممنوعة. الأهم هو احترام التشوير وعدم عرقلة السير أو خلق خطر.'),
  Question(id:'q37',category:'المخالفات',text:'احترام السرعة المحددة كيساعد على شنو؟',options:['زيادة الخطر','تحسين التحكم وتقليل الخطر','منع السيارة من الحركة','زيادة استهلاك الهاتف'],answer:1,explanation:'السرعة المناسبة كتخلي عندك تحكم أحسن ووقت أكثر باش تتصرف فحالة الخطر.'),
  Question(id:'q38',category:'المركبة',text:'إلى بان ليك عطب كيأثر على السلامة، شنو الأفضل؟',options:['تكمل بسرعة','توقف فبلاصة آمنة وتتصرف حسب الحالة','تتجاهلو','تطفي المحرك وسط الطريق'],answer:1,explanation:'إلا كان العطب كيهدد السلامة، ما تكملش بطريقة كتقدر تعرضك والآخرين للخطر. وقف فبلاصة آمنة إذا أمكن.'),
  Question(id:'q39',category:'علامات التشوير',text:'علاش خاصك تفهم علامات التشوير وماشي غير تحفظ شكلها؟',options:['باش تجاوب فالتيست فقط','باش تعرف شنو الخطر وشنو خاصك تدير فالطريق','باش تزيد السرعة','باش تتجاهل القواعد'],answer:1,explanation:'الفهم كيساعدك تطبق العلامة فالحياة اليومية وما تبقاش غير حافظ شكلها.'),
  Question(id:'q40',category:'السلامة',text:'شنو من هاد السلوكات آمن أكثر؟',options:['السرعة والتوتر','الهدوء والتركيز ومسافة الأمان واحترام التشوير','الهاتف أثناء السياقة','التجاوز بلا رؤية'],answer:1,explanation:'السياقة الآمنة كتجمع بين التركيز والهدوء واحترام القواعد والمسافات المناسبة.'),
];


final extraQuestions = <Question>[
  Question(id:'q41',category:'قواعد الطريق',text:'إلى قربتي من تقاطع والرؤية ماشي واضحة، شنو الأحسن؟',options:['تزيد السرعة','تنقص السرعة وتدخل غير ملي تتأكد','تغمض عينيك وتدوز','تلصق فالسيارة اللي قدامك'],answer:1,explanation:'إلى كانت الرؤية محدودة، خاصك تنقص السرعة وتبقى واجد لأي خطر قبل ما تدخل.'),
  Question(id:'q42',category:'قواعد الطريق',text:'قبل ما تخرج من بلاصة الوقوف، شنو خاصك تدير؟',options:['تخرج دغيا','تشوف المرايات وتعطي الإشارة وتتأكد بلي الخروج آمن','تستعمل الهاتف','تسوق بالعكس بلا ما تشوف'],answer:1,explanation:'خاصك تراقب الطريق، تعطي الإشارة وتخرج غير ملي تكون المناورة آمنة.'),
  Question(id:'q43',category:'قواعد الطريق',text:'إلى كان المسار ديالك مسدود بعائق، شنو خاصك تراعي؟',options:['تدوز بأي طريقة','تشوف الحركة وتتفادى العائق بلا ما تعرض الآخرين للخطر','توقف وسط الطريق بلا سبب','تسرع'],answer:1,explanation:'خاصك تدير المناورة بهدوء وتخلي الأولوية والسلامة فالحساب.'),
  Question(id:'q44',category:'قواعد الطريق',text:'فاش كتقرب من ممر الراجلين، شنو التصرف اللي كينقص الخطر؟',options:['تزيد السرعة','تنقص السرعة وتراقب الجهتين','تشوف غير لقدام','تستعمل الهاتف'],answer:1,explanation:'المراقبة والسرعة المناسبة كيعطيوك وقت أكثر باش تتصرف.'),
  Question(id:'q45',category:'قواعد الطريق',text:'إلى بغيتي ترجع للخلف، شنو خاصك تدير؟',options:['تعتمد غير على الكاميرا','تتأكد من المساحة كاملة وتتحرك ببطء','تسرع','ما تشوفش الجوانب'],answer:1,explanation:'الرجوع للخلف خاصو مراقبة دقيقة وتحرك ببطء، والكاميرا إلا كانت غير وسيلة مساعدة.'),
  Question(id:'q46',category:'قواعد الطريق',text:'إلى حسّيتي أن المناورة ما بقاتش آمنة، شنو تدير؟',options:['تكمل بأي ثمن','توقف المناورة وتعاود غير ملي تولي آمنة','تزيد السرعة','تستعمل الكلاكسون فقط'],answer:1,explanation:'السلامة أهم من إكمال المناورة بسرعة.'),
  Question(id:'q47',category:'قواعد الطريق',text:'علاش خاصك تراقب المرايات بشكل منتظم؟',options:['باش تشوف غير لون السيارة','باش تعرف شنو واقع حداك ووراك','باش تزيد السرعة','باش ما تستعملش الإشارة'],answer:1,explanation:'المرايات كتعطيك معلومات على السيارات والمستعملين اللي حداك ووراك.'),
  Question(id:'q48',category:'قواعد الطريق',text:'إلى كانت الحركة عامرة، شنو الأحسن؟',options:['تبدل المسار بلا مراقبة','تخلي مسافة وتدير المناورات بهدوء','تلصق فالسيارة اللي قدامك','تستعمل الهاتف'],answer:1,explanation:'الحركة الكثيفة كتحتاج تركيز أكثر ومناورات محسوبة.'),
  Question(id:'q49',category:'قواعد الطريق',text:'شنو كتدير قبل أي تغيير فالاتجاه؟',options:['كتشوف الإشارة والمرايات والوضعية','كتدور بلا إشارة','كتسرع','كتشوف الهاتف'],answer:0,explanation:'خاص المراقبة والإشارة والتأكد من السلامة قبل تغيير الاتجاه.'),
  Question(id:'q50',category:'قواعد الطريق',text:'إلى كانت العلامة كتفرض اتجاه، واش كتقدر تخالفها حيث مستعجل؟',options:['نعم','لا، خاص احترام التشوير','غير فالليل','غير إلا كانت الطريق خاوية'],answer:1,explanation:'الاستعجال ماشي سبب باش تخالف التشوير.'),
  Question(id:'q51',category:'السائق',text:'إلى كنت مرهق بزاف، شنو الأحسن قبل السياقة؟',options:['تسوق بسرعة','ترتاح قبل ما تسوق','تشرب شي حاجة منبهة وتكمل بلا توقف','تستعمل الهاتف'],answer:1,explanation:'الإرهاق كيضعف التركيز ورد الفعل، والراحة هي الاختيار الآمن.'),
  Question(id:'q52',category:'السائق',text:'شنو كيوقع للانتباه ملي كتكون مشغول بالهاتف؟',options:['كيزيد','كيقدر ينقص بزاف','ما كيتبدلش','كيولي أقوى'],answer:1,explanation:'الهاتف كيشتت الانتباه وكيخلي السائق يفقد جزء من التركيز على الطريق.'),
  Question(id:'q53',category:'السائق',text:'إلى كنت متوتر، شنو كيساعدك تسوق بأمان؟',options:['الهدوء وتفادي القرارات المتسرعة','السرعة','الكلاكسون المستمر','التجاوز العشوائي'],answer:0,explanation:'الهدوء كيساعدك تاخذ قرارات أحسن وتتفادى التصرفات الخطيرة.'),
  Question(id:'q54',category:'السائق',text:'علاش خاص السائق يكون مركز حتى فالطريق اللي كيعرفها؟',options:['حيت الخطر يقدر يبان فأي وقت','حيت الطريق ديما خطيرة','باش يزيد السرعة','باش ما يستعملش المرايات'],answer:0,explanation:'حتى الطريق المعروفة تقدر توقع فيها تغييرات أو أخطار مفاجئة.'),
  Question(id:'q55',category:'السائق',text:'إلى حسّيتي بدوخة وانت سايق، شنو تدير؟',options:['تكمل بسرعة','توقف فبلاصة آمنة وتطلب المساعدة إلا احتاجيتي','تفتح الهاتف','تبدل المسار بسرعة'],answer:1,explanation:'الدوخة كتقدر تأثر على التحكم، لذلك خاص توقف بأمان وما تكملش وانت ما قادرش تسوق مزيان.'),
  Question(id:'q56',category:'السائق',text:'قبل رحلة طويلة، شنو كيساعدك تكون واجد؟',options:['تنظم الراحة وتفحص السيارة','تسوق بلا توقف','تزيد السرعة','تنسى الحزام'],answer:0,explanation:'الراحة والتحضير وفحص السيارة كيساعدو على السلامة فالرحلات الطويلة.'),
  Question(id:'q57',category:'السائق',text:'إلى شي راكب كيشتتك، شنو الأحسن؟',options:['تبقى مركز وتوقف إلا احتاج الأمر فبلاصة آمنة','تغضب وتسوق بسرعة','تستعمل الهاتف','تتجاوز بلا رؤية'],answer:0,explanation:'السائق خاصو يحافظ على التركيز، وإذا كان التشتيت كبير يقدر يوقف بأمان.'),
  Question(id:'q58',category:'السائق',text:'السياقة تحت تأثير مادة كتأثر على الوعي شنو كتقدر تدير؟',options:['تحسن رد الفعل','تضعف التركيز والحكم على الوضعية','ما كتأثرش','كتزيد الرؤية'],answer:1,explanation:'أي مادة كتأثر على الوعي أو اليقظة تقدر تخلي السياقة أخطر.'),
  Question(id:'q59',category:'السائق',text:'شنو الدور ديال حزام السلامة؟',options:['الحماية فحالة الاصطدام','زيادة السرعة','تحسين الراديو','تقليل الضوء'],answer:0,explanation:'الحزام كيساعد يحمي الجسم فحالة اصطدام أو توقف مفاجئ.'),
  Question(id:'q60',category:'السائق',text:'إلى كنت غادي تسوق بالليل وعيان، شنو الأحسن؟',options:['توقف وترتاح قبل ما تكمل','تزيد السرعة','تفتح الهاتف','تطفي الأضواء'],answer:0,explanation:'التعب فالليل كيقدر يزيد الخطر، والراحة أحسن من مواصلة السياقة وانت عيان.'),
  Question(id:'q61',category:'المركبة',text:'علاش خاصك تفحص العجلات قبل رحلة طويلة؟',options:['باش تعرف الحالة ديالها والضغط','باش تبدل لون السيارة','باش يزيد الراديو','ما كاين حتى سبب'],answer:0,explanation:'حالة العجلات والضغط ديالها مهمين للتوازن والتماسك والتحكم.'),
  Question(id:'q62',category:'المركبة',text:'إلى كانت العجلة باينة ناقصة بزاف، شنو الأحسن؟',options:['تتجاهلها','تتأكد من الضغط وتعالج المشكل قبل السياقة العادية','تزيد السرعة','تفرغها أكثر'],answer:1,explanation:'العجلة اللي الضغط ديالها غير مناسب تقدر تأثر على التحكم والسلامة.'),
  Question(id:'q63',category:'المركبة',text:'شنو خاصك تدير إلا كان الزجاج الأمامي موسخ؟',options:['تسوق كيف ما كان','تنظفو باش تبقى الرؤية واضحة','تطفي المساحات','تستعمل الهاتف'],answer:1,explanation:'الرؤية الواضحة مهمة، خصوصاً فالليل والجو الماطر.'),
  Question(id:'q64',category:'المركبة',text:'إلى كانت المساحات ما كتخدمش مزيان فالمطر، شنو الأحسن؟',options:['تكمل بسرعة','تصلح المشكل قبل استعمال السيارة فظروف صعبة','تطفي الأضواء','تستعمل الهاتف'],answer:1,explanation:'المساحات كتعاون على الرؤية، وأي خلل فيها كيقدر يزيد الخطر فالمطر.'),
  Question(id:'q65',category:'المركبة',text:'علاش خاص الأضواء تكون خدامة مزيان؟',options:['باش تشوف ويتشافوك مستعملي الطريق','باش تزيد السرعة','باش ينقص البنزين فقط','ماشي مهمة'],answer:0,explanation:'الأضواء كتعاون على الرؤية وعلى رؤية السيارة من طرف الآخرين.'),
  Question(id:'q66',category:'المركبة',text:'قبل الانطلاق، علاش خاصك تضبط الكرسي؟',options:['باش تكون وضعية السياقة والتحكم مناسبين','باش تزيد السرعة','باش تبدل لون السيارة','ماشي مهم'],answer:0,explanation:'الوضعية المناسبة كتعاون على التحكم والراحة والرؤية.'),
  Question(id:'q67',category:'المركبة',text:'شنو كتدير إلا بان عطب فالمكابح؟',options:['تكمل عادي','توقف بأمان وما تستعملش السيارة حتى يتصلح المشكل','تزيد السرعة','تستعمل الكلاكسون'],answer:1,explanation:'مشكل فالمكابح يقدر يكون خطير، وما خاصش الاستمرار فالسياقة بطريقة عادية.'),
  Question(id:'q68',category:'المركبة',text:'شنو كيساعدك تعرف الحالة العامة ديال السيارة؟',options:['المراقبة والصيانة المنتظمة','لون السيارة','الراديو','الهاتف'],answer:0,explanation:'الصيانة والمراقبة المنتظمة كتساعد تكتشف الأعطاب قبل ما تولي أخطر.'),
  Question(id:'q69',category:'المركبة',text:'إلى سخن المحرك بشكل غير عادي، شنو الأحسن؟',options:['تزيد السرعة','توقف فبلاصة آمنة وتتصرف حسب تعليمات السيارة','تفتح الهاتف','تكمل بأي ثمن'],answer:1,explanation:'السخونية غير العادية ممكن تكون علامة على مشكل، والأفضل التوقف بأمان واتباع تعليمات السيارة.'),
  Question(id:'q70',category:'المركبة',text:'علاش ما خاصش تحط حاجات كتسد الرؤية قدام السائق؟',options:['حيت كتقدر تحجب جزء من الطريق','باش تزيد السرعة','باش ينقص البنزين','ماشي مشكل'],answer:0,explanation:'الرؤية خاصها تبقى واضحة بلا حواجز كتخلي السائق ما يشوفش الطريق مزيان.'),
  Question(id:'q71',category:'السلامة',text:'إلى كانت الرؤية ضعيفة بسبب الضباب، شنو الأحسن؟',options:['تزيد السرعة','تنقص السرعة وتستعمل الإنارة المناسبة وتزيد الحذر','تطفي الأضواء','تلصق فالسيارة اللي قدامك'],answer:1,explanation:'الضباب كيضعف الرؤية، لذلك خاص تخفيف السرعة وزيادة الحذر.'),
  Question(id:'q72',category:'السلامة',text:'فالطريق المبللة، علاش خاص مسافة أكبر؟',options:['حيت الفرملة تقدر تحتاج مسافة أكثر','باش تزيد السرعة','باش تتجاوز','ما كاين حتى سبب'],answer:0,explanation:'الماء يقدر ينقص التماسك ويخلي التوقف أصعب.'),
  Question(id:'q73',category:'السلامة',text:'شنو الخطر ديال السياقة بسرعة ما مناسبةش للجو؟',options:['كتزيد القدرة على التحكم','كتقدر تزيد خطر فقدان التحكم والحادث','ما كتأثرش','كتحسن الرؤية'],answer:1,explanation:'السرعة خاصها تكون مناسبة للطريق والجو والرؤية، ماشي غير للحد المعلن.'),
  Question(id:'q74',category:'السلامة',text:'إلى كان الطريق زلق، شنو الأحسن؟',options:['حركات مفاجئة','حركات هادئة وسرعة مناسبة ومسافة أمان','فرملة قوية بلا سبب','تجاوز سريع'],answer:1,explanation:'الحركات المفاجئة فوق طريق زلق تقدر تنقص التحكم.'),
  Question(id:'q75',category:'السلامة',text:'إلى وقع حادث قدامك، شنو أول حاجة خاصك تفكر فيها؟',options:['السلامة ديالك وسلامة الآخرين','تصور فيديو','تسرع','توقف وسط الطريق بلا انتباه'],answer:0,explanation:'السلامة أولاً، وخاص تتصرف بطريقة ما تزيدش الخطر.'),
  Question(id:'q76',category:'السلامة',text:'علاش خاصك تخلي مسافة أمان فالطريق السريع؟',options:['باش يكون عندك وقت للتصرف والفرملة','باش تزيد السرعة','باش تتجاوز من اليمين','ماشي مهمة'],answer:0,explanation:'فالسرعات العالية كتكون الحاجة لمسافة كافية للتفاعل والتوقف أكبر.'),
  Question(id:'q77',category:'السلامة',text:'إلى كنت سايق وكتحس بعينيك كيتسدّو من النعاس، شنو الحل؟',options:['تكمل حتى توصل','توقف وترتاح','تزيد الموسيقى فقط','تزيد السرعة'],answer:1,explanation:'النعاس علامة خطر، والراحة هي الحل الآمن.'),
  Question(id:'q78',category:'السلامة',text:'شنو كيساعدك تتفادى المفاجآت فالطريق؟',options:['التركيز والمراقبة المستمرة','الهاتف','السرعة','السياقة بلا مرايات'],answer:0,explanation:'المراقبة المستمرة كتخليك تكتشف الخطر بكري وتتصرف فالمناسب.'),
  Question(id:'q79',category:'المخالفات',text:'شنو الهدف من احترام قوانين السير؟',options:['تنظيم السير وحماية الناس','تعطيل السائقين فقط','زيادة الحوادث','ما عندوش هدف'],answer:0,explanation:'القواعد كتعاون على تنظيم حركة السير وتقليل المخاطر.'),
  Question(id:'q80',category:'المخالفات',text:'إلى خالفت علامة منع، شنو ممكن يوقع؟',options:['ما كاين والو ديما','ممكن تكون مخالفة حسب القاعدة والحالة','كتربح نقاط','كتولي عندك أولوية'],answer:1,explanation:'مخالفة التشوير ممكن تشكل مخالفة حسب الحالة والنص القانوني اللي كينطبق.'),
  Question(id:'q81',category:'المخالفات',text:'علاش ما خاصش نستعملو الهاتف باليد أثناء السياقة؟',options:['حيت كيشغل الانتباه واليد والعين','حيت كيزيد السرعة','حيت كيصلح السيارة','ما كاين حتى سبب'],answer:0,explanation:'استعمال الهاتف كيشغل الانتباه وكيقدر يأخر رد الفعل.'),
  Question(id:'q82',category:'المخالفات',text:'إلى كانت شي قاعدة ما متأكدش منها، شنو الأحسن؟',options:['تخمن وتطبق اللي بغيتي','ترجع لمصدر موثوق أو تسول مهني قبل اعتماد المعلومة','تنشرها للناس','تتجاهل القاعدة'],answer:1,explanation:'فالمعلومات القانونية خاص الاعتماد على مصدر موثوق وماشي التخمين.'),
  Question(id:'q83',category:'المخالفات',text:'واش الاستعجال كيعطيك الحق تتجاوز القواعد؟',options:['نعم','لا','غير فالليل','غير فالطريق خاوية'],answer:1,explanation:'الاستعجال ما كيبدلش قواعد السلامة ولا التشوير.'),
  Question(id:'q84',category:'المخالفات',text:'شنو خاصك تدير إلا ما فهمتيش علامة؟',options:['تتجاهلها','تنقص السرعة وتبحث على المعنى وتتبع باقي التشوير بحذر','تزيد السرعة','توقف وسط الطريق'],answer:1,explanation:'ملي ما تكونش فاهم، تخفيف السرعة والحذر كيساعدوك تتصرف بأمان.'),
  Question(id:'q85',category:'علامات التشوير',text:'علاش كاينين علامات التحذير؟',options:['باش ينبهونا لخطر محتمل','باش يزيدو السرعة','باش يمنعو كل الطرق','باش يزينو الطريق'],answer:0,explanation:'علامات التحذير كتنبّه السائق لخطر أو وضعية خاصها الانتباه.'),
  Question(id:'q86',category:'علامات التشوير',text:'شنو خاصك تدير ملي كتقرا علامة خطر؟',options:['تتجاهلها','تعدل السرعة والسياقة حسب الخطر','تزيد السرعة','تسد المرايات'],answer:1,explanation:'العلامة كتطلب منك تهيأ راسك للخطر وتتصرف بطريقة مناسبة.'),
  Question(id:'q87',category:'علامات التشوير',text:'علامة المنع كتدل على شنو؟',options:['فعل أو حركة ممنوعة فالنطاق اللي كينطبق عليها','الخطر فقط','الخدمات','موقف السيارات'],answer:0,explanation:'علامات المنع كتحدد أفعال أو حركات ما مسموحاش حسب العلامة.'),
  Question(id:'q88',category:'علامات التشوير',text:'علامات الإلزام كتطلب شنو؟',options:['اتباع توجيه محدد','التوقف ديما','التجاوز ديما','إطفاء الأضواء'],answer:0,explanation:'علامات الإلزام كتفرض توجيه أو سلوك محدد حسب الرمز.'),
  Question(id:'q89',category:'علامات التشوير',text:'إلى كان التشوير المؤقت مختلف بسبب الأشغال، شنو خاصك تدير؟',options:['تتبع التشوير المؤقت اللي كينظم الوضعية','تتجاهلو','تزيد السرعة','تمشي عكس السير'],answer:0,explanation:'الأشغال تقدر تبدل تنظيم السير مؤقتاً، وخصك تتبع التشوير الموجود فداك الوقت.'),
  Question(id:'q90',category:'علامات التشوير',text:'علاش خاصك تبقى كتراقب العلامات حتى من بعد ما دوزتي وحدة؟',options:['حيت القواعد والوضعية تقدر تتبدل','باش تزيد السرعة','ماشي مهم','باش ما تشوفش الطريق'],answer:0,explanation:'التشوير كيتبدل حسب المكان والوضعية، والمراقبة خاصها تبقى مستمرة.'),
  Question(id:'q91',category:'قواعد الطريق',text:'إلى بغيت تدير توقف قصير، شنو خاصك تتأكد منو؟',options:['المكان مسموح وما كتعرقلش السير وما كتخلقش خطر','غير السيارة اللي وراك','اللون ديال الرصيف فقط','ما خاصك تتأكد من والو'],answer:0,explanation:'خاص اختيار مكان آمن ومسموح وما يعرقلش حركة السير.'),
  Question(id:'q92',category:'قواعد الطريق',text:'فاش كتخرج من تقاطع، شنو خاصك تدير؟',options:['تزيد السرعة ديما','تكمل المراقبة وتأكد بلي الطريق قدامك آمنة','تشوف الهاتف','تطفي الأضواء'],answer:1,explanation:'المراقبة ما كتساليش بمجرد دخول التقاطع؛ خاص التأكد حتى تكمل المناورة بأمان.'),
  Question(id:'q93',category:'قواعد الطريق',text:'إلى كان شي مستعمل للطريق قريب منك وما بانش ليك مزيان، شنو الأحسن؟',options:['تزيد السرعة','تعتبره خطر محتمل وتنقص السرعة','تتجاهلو','تستعمل الهاتف'],answer:1,explanation:'ملي ما تكونش متأكد من الوضعية، خذ الاحتياط وخلي وقت ومسافة للتصرف.'),
  Question(id:'q94',category:'قواعد الطريق',text:'شنو الدور ديال الإشارة قبل تغيير المسار؟',options:['كتعلم الآخرين بالنية ديالك للمناورة','كتعطيك الأسبقية بوحدها','كتخليك تزيد السرعة','ما عندها حتى دور'],answer:0,explanation:'الإشارة كتبلغ الآخرين بالنية، ولكن ما كتغنيش على المراقبة والتأكد من السلامة.'),
  Question(id:'q95',category:'قواعد الطريق',text:'إلى كانت السيارة اللي قدامك كتفرمل، شنو خاصك تدير؟',options:['تلصق فيها','تخلي مسافة وتكون واجد تفرمل','تتجاوز بلا رؤية','تستعمل الهاتف'],answer:1,explanation:'خاص تحافظ على مسافة كافية باش يكون عندك وقت للتصرف.'),
  Question(id:'q96',category:'المركبة',text:'شنو أهمية المرايات الجانبية؟',options:['كتعاونك تراقب الجوانب والمركبات اللي حداك','كتزيد السرعة','كتبدل الإضاءة','ماشي مهمة'],answer:0,explanation:'المرايات الجانبية كتعاون فالمراقبة قبل تغيير المسار أو المناورة.'),
  Question(id:'q97',category:'المركبة',text:'إلى كان شي ضو ما خدامش، شنو الأحسن؟',options:['تصلحو قبل ما تعتمد على السيارة فالظروف اللي كتحتاج فيه','تتجاهلو ديما','تطفي باقي الأضواء','تزيد السرعة'],answer:0,explanation:'الإنارة جزء مهم من الرؤية والسلامة، وخص الأعطاب تتعالج.'),
  Question(id:'q98',category:'المركبة',text:'شنو خاصك تدير مع الحمولة داخل السيارة؟',options:['تخليها مأمنة وما تحجبش الرؤية','تحطها قدام السائق','تحطها فوق الدواسات','تخليها تتحرك بحرية'],answer:0,explanation:'الحاجيات خاصها تكون مرتبة ومأمنة وما تعرقلش السائق أو الرؤية.'),
  Question(id:'q99',category:'المركبة',text:'إلى كانت المراية الداخلية ما مضبوطةش، شنو المشكل؟',options:['الرؤية للور تقدر تكون ناقصة','السرعة كتزيد','المحرك كيتوقف','ما كاين حتى مشكل'],answer:0,explanation:'ضبط المرايات مهم باش تكون عندك رؤية مزيانة للمحيط ديالك.'),
  Question(id:'q100',category:'السلامة',text:'شنو أحسن طريقة باش تتعلم السياقة النظرية؟',options:['الحفظ بلا فهم','الفهم والتدريب ومراجعة الأخطاء','الاعتماد على التخمين','حفظ الأجوبة فقط'],answer:1,explanation:'الفهم والتدريب ومراجعة الأخطاء كيعطيوك استعداد أحسن للسياقة والامتحان.'),
];

final allQuestions = <Question>[...questions, ...extraQuestions];

const signs = <RoadSign>[
  RoadSign('قف','المنع والتنظيم','خاصك توقف كامل قبل ما تكمل.','وقف، شوف الطريق مزيان، ومن بعد كمل إلا كان آمن.','قف'),
  RoadSign('ممنوع الدخول','المنع','الدخول من هاد الجهة ممنوع.','ما تدخلش من هاد الاتجاه وقلب على المسار المسموح.','⛔'),
  RoadSign('ممنوع الوقوف','المنع','الوقوف ممنوع فالمكان اللي كينطبق عليه المنع.','ما توقفش إلا كان المنع كينطبق على المكان.','P'),
  RoadSign('ممنوع التجاوز','المنع','التجاوز ممنوع فالمقطع اللي كتشملو العلامة.','بقى فالمسار ديالك حتى تسالي الحالة أو المنع.','⇄'),
  RoadSign('السرعة القصوى','المنع','السرعة ما خاصهاش تفوت الرقم اللي فالعلامة.','احترم الرقم وعدل السرعة حسب الطريق والطقس.','50'),
  RoadSign('إعطاء الأسبقية','الأسبقية','خاصك تعطي الأسبقية حسب العلامة والوضعية.','نقص السرعة وتأكد قبل الدخول.','▽'),
  RoadSign('طريق ذات أسبقية','الأسبقية','كتبيّن بلي الطريق عندها وضعية أسبقية حسب العلامة.','بقى مركز وراقب العلامات اللي ممكن تبدل هاد الوضعية.','◆'),
  RoadSign('نهاية الأسبقية','الأسبقية','كتعلن نهاية وضعية الطريق ذات الأسبقية.','بقى منتبه للتشوير اللي جاي.','◇'),
  RoadSign('خطر: منعرج','الخطر','كاين منعرج خاصك تنتبه ليه.','نقص السرعة وخليك واجد لأي خطر.','↪'),
  RoadSign('خطر: أطفال','الخطر','ممكن يكونو أطفال قريبين من الطريق.','نقص السرعة وراقب الجوانب وممرات العبور.','⚠'),
  RoadSign('خطر: ممر الراجلين','الخطر','كاين احتمال عبور الراجلين.','نقص السرعة وخليك واجد توقف.','🚶'),
  RoadSign('أشغال فالطريق','الخطر','كاينة أشغال أو تغيير مؤقت فالسير.','تبع التشوير المؤقت ونقص السرعة.','🚧'),
  RoadSign('اتجاه إجباري لليمين','الإلزام','خاصك تتبع الاتجاه اللي كتشير ليه العلامة.','دير المناورة المطلوبة فالأمان.','→'),
  RoadSign('اتجاه إجباري لليسار','الإلزام','خاصك تمشي فالجهة المحددة.','تبع السهم وما تخالفش الاتجاه.','←'),
  RoadSign('دوران إجباري','الإلزام','خاصك تتبع الاتجاه الدائري المحدد.','دخل بحذر وتبع الأسبقية والتشوير.','↻'),
  RoadSign('موقف السيارات','الخدمات','كتشير لمكان مخصص لركن السيارات.','ركن غير فالمكان المسموح وبطريقة ما كتعرقلش السير.','🅿'),
  RoadSign('مستشفى','الخدمات','كتشير لمرفق صحي قريب.','سوق بهدوء ورد بالك من الحركة والراجلين.','✚'),
  RoadSign('محطة الوقود','الخدمات','كتشير لمكان للتزود بالوقود.','تبع الولوج والخروج بحذر.','⛽'),
];

class PermisMarocApp extends StatelessWidget {
  final SharedPreferences prefs;
  const PermisMarocApp({super.key, required this.prefs});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'بيرمي مغربي',
    theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF0F766E)), scaffoldBackgroundColor: const Color(0xFFF7F8FA)),
    home: HomePage(prefs: prefs),
  );
}

class HomePage extends StatefulWidget {
  final SharedPreferences prefs;
  const HomePage({super.key, required this.prefs});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  Set<String> failed = {}, saved = {};
  int tests = 0, best = 0, attempted = 0, correct = 0;
  @override
  void initState() { super.initState(); _load(); }
  void _load() {
    failed = {...(widget.prefs.getStringList('failed') ?? [])};
    saved = {...(widget.prefs.getStringList('saved') ?? [])};
    tests = widget.prefs.getInt('tests') ?? 0;
    best = widget.prefs.getInt('best') ?? 0;
    attempted = widget.prefs.getInt('attempted') ?? 0;
    correct = widget.prefs.getInt('correct') ?? 0;
  }
  Future<void> persist() async {
    await widget.prefs.setStringList('failed', failed.toList()..sort());
    await widget.prefs.setStringList('saved', saved.toList()..sort());
    await widget.prefs.setInt('tests', tests);
    await widget.prefs.setInt('best', best);
    await widget.prefs.setInt('attempted', attempted);
    await widget.prefs.setInt('correct', correct);
    if (mounted) setState(() {});
  }
  void openQuiz({String? category, bool exam = false, List<Question>? custom}) {
    final source = custom ?? (category == null ? allQuestions : allQuestions.where((q) => q.category == category).toList());
    Navigator.push(context, MaterialPageRoute(builder: (_) => QuizPage(
      title: exam ? 'تيست B' : (category ?? 'تيست سريع'), source: source, exam: exam,
      failed: failed, saved: saved,
      onAnswer: (q, isCorrect) { if (isCorrect) failed.remove(q.id); else failed.add(q.id); attempted++; if (isCorrect) correct++; persist(); },
      onExamDone: (score) { tests++; if (score > best) best = score; persist(); },
    )));
  }
  @override
  Widget build(BuildContext context) {
    final pages = [
      Dashboard(onLearn: () => setState(() => tab = 1), onExam: () => openQuiz(exam: true), onSigns: () => setState(() => tab = 2), failedCount: failed.length, best: best),
      LearnPage(onCategory: (c) => openQuiz(category: c)),
      SignsPage(),
      ProgressPage(tests: tests, best: best, attempted: attempted, correct: correct, failed: failed, saved: saved, onFailed: () => _openReview('الأخطاء ديالك', failed), onSaved: () => _openReview('الأسئلة المحفوظة', saved), onReset: _reset),
    ];
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(
      body: SafeArea(child: pages[tab]),
      bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (v) => setState(() => tab = v), destinations: const [
        NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
        NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'نتعلمو'),
        NavigationDestination(icon: Icon(Icons.traffic_outlined), selectedIcon: Icon(Icons.traffic), label: 'التشوير'),
        NavigationDestination(icon: Icon(Icons.insights_outlined), selectedIcon: Icon(Icons.insights), label: 'المستوى'),
      ]),
    ));
  }
  void _openReview(String title, Set<String> ids) => Navigator.push(context, MaterialPageRoute(builder: (_) => ReviewPage(title: title, ids: ids, saved: saved, failed: failed, onChanged: persist)));
  Future<void> _reset() async {
    await widget.prefs.clear();
    setState(() { failed = {}; saved = {}; tests = best = attempted = correct = 0; });
  }
}

class Dashboard extends StatelessWidget {
  final VoidCallback onLearn, onExam, onSigns; final int failedCount, best;
  const Dashboard({super.key, required this.onLearn, required this.onExam, required this.onSigns, required this.failedCount, required this.best});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const SizedBox(height: 8), const Text('السلام عليكم 👋', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
    const SizedBox(height: 6), const Text('واجد تدوز البيرمي؟ نتعلمو بشوية بشوية ونشوفو المستوى ديالك.', style: TextStyle(fontSize: 16, color: Colors.black54, height: 1.5)),
    const SizedBox(height: 20),
    Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(color: const Color(0xFF0F766E), borderRadius: BorderRadius.circular(24)), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('🇲🇦 بيرمي مغربي', style: TextStyle(color: Colors.white, fontSize: 27, fontWeight: FontWeight.bold)), SizedBox(height: 8),
      Text('تعلم، تمرّن، ودير تيستات باش تكون واجد.', style: TextStyle(color: Colors.white70, fontSize: 16)),
    ])),
    const SizedBox(height: 16), _BigButton(icon: Icons.menu_book, label: 'نبداو نتعلمو', onTap: onLearn),
    const SizedBox(height: 10), _BigButton(icon: Icons.assignment_turned_in, label: 'دير تيست B — 40 سؤال', onTap: onExam),
    const SizedBox(height: 10), _BigButton(icon: Icons.traffic, label: 'نتعلمو علامات التشوير', onTap: onSigns),
    const SizedBox(height: 18), Row(children: [Expanded(child: _InfoCard(title: '${allQuestions.length}', sub: 'سؤال تدريبي', icon: Icons.quiz)), const SizedBox(width: 10), Expanded(child: _InfoCard(title: best == 0 ? '—' : '$best/40', sub: 'أحسن نتيجة', icon: Icons.emoji_events))]),
    const SizedBox(height: 10), Card(child: ListTile(leading: const Icon(Icons.error_outline), title: const Text('الأخطاء ديالك'), subtitle: Text('$failedCount سؤال خاصك تراجعهم'))),
    const SizedBox(height: 18), const Text('شنو غادي تلقى؟', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
    const _Feature(text: 'قواعد الطريق والأسبقية', icon: Icons.alt_route), const _Feature(text: 'علامات التشوير', icon: Icons.traffic), const _Feature(text: 'السائق والسيارة والسلامة', icon: Icons.health_and_safety), const _Feature(text: 'الأخطاء والمحفوظات', icon: Icons.bookmark_border),
  ]);
}
class _BigButton extends StatelessWidget { final IconData icon; final String label; final VoidCallback onTap; const _BigButton({required this.icon, required this.label, required this.onTap}); @override Widget build(BuildContext c) => SizedBox(height: 58, child: FilledButton.icon(onPressed: onTap, icon: Icon(icon), label: Text(label, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)))); }
class _InfoCard extends StatelessWidget { final IconData icon; final String title, sub; const _InfoCard({required this.icon, required this.title, required this.sub}); @override Widget build(BuildContext c) => Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.black12)), child: Row(children: [Icon(icon, color: const Color(0xFF0F766E)), const SizedBox(width: 9), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 19)), Text(sub, style: const TextStyle(color: Colors.black54))]))])); }
class _Feature extends StatelessWidget { final String text; final IconData icon; const _Feature({required this.text, required this.icon}); @override Widget build(BuildContext c) => ListTile(contentPadding: EdgeInsets.zero, leading: CircleAvatar(backgroundColor: const Color(0xFFE6FFFA), child: Icon(icon, color: const Color(0xFF0F766E))), title: Text(text)); }

class LearnPage extends StatelessWidget {
  final ValueChanged<String> onCategory; const LearnPage({super.key, required this.onCategory});
  @override Widget build(BuildContext c) => ListView(padding: const EdgeInsets.all(20), children: [const Text('نتعلمو شوية بشوية 📚', style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold)), const SizedBox(height: 8), const Text('اختار الموضوع اللي بغيتي تراجع.', style: TextStyle(color: Colors.black54)), const SizedBox(height: 18), ...categories.map((x) => Card(child: ListTile(leading: const Icon(Icons.school_outlined), title: Text(x, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text('${allQuestions.where((q) => q.category == x).length} أسئلة فهاد القسم'), trailing: const Icon(Icons.chevron_left), onTap: () => onCategory(x))))]);
}

class QuizPage extends StatefulWidget {
  final String title; final List<Question> source; final bool exam; final Set<String> failed, saved; final void Function(Question,bool) onAnswer; final ValueChanged<int> onExamDone;
  const QuizPage({super.key, required this.title, required this.source, required this.exam, required this.failed, required this.saved, required this.onAnswer, required this.onExamDone});
  @override State<QuizPage> createState() => _QuizPageState();
}
class _QuizPageState extends State<QuizPage> {
  late List<Question> qs; int i=0, score=0; int? selected; final List<String> wrong=[]; Timer? timer; int secondsLeft=1800;
  @override void initState(){super.initState(); qs=[...widget.source]..shuffle(Random()); if(widget.exam && qs.length>40) qs=qs.take(40).toList(); if(widget.exam){ timer=Timer.periodic(const Duration(seconds:1),(t){ if(!mounted)return; if(secondsLeft<=0){t.cancel(); _finishByTime();} else {setState(()=>secondsLeft--);} }); }}
  @override void dispose(){timer?.cancel(); super.dispose();}
  void _finishByTime(){ if(qs.isEmpty)return; Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>ResultPage(title:widget.title,score:score,total:qs.length,wrong:wrong,exam:widget.exam))); widget.onExamDone(score); }
  void next(){ if(selected==null)return; final q=qs[i]; final ok=selected==q.answer; if(ok){score++;widget.failed.remove(q.id);}else{widget.failed.add(q.id);wrong.add(q.id);} widget.onAnswer(q,ok); if(i==qs.length-1){timer?.cancel(); if(widget.exam)widget.onExamDone(score); Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>ResultPage(title:widget.title,score:score,total:qs.length,wrong:wrong,exam:widget.exam)));}else{setState((){i++;selected=null;});}}
  @override
  Widget build(BuildContext c) {
    final q = qs[i];
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text('${widget.title} · ${i + 1}/${qs.length}'),
          actions: [
            if (widget.exam)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Center(
                  child: Text(
                    '${secondsLeft ~/ 60}:${(secondsLeft % 60).toString().padLeft(2, '0')}',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
              ),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            LinearProgressIndicator(
              value: (i + 1) / qs.length,
              minHeight: 8,
              borderRadius: BorderRadius.circular(20),
            ),
            const SizedBox(height: 18),
            Row(
              children: [
                Expanded(
                  child: Text(
                    q.category,
                    style: const TextStyle(
                      color: Color(0xFF0F766E),
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                IconButton(
                  onPressed: () => setState(
                    () => widget.saved.contains(q.id)
                        ? widget.saved.remove(q.id)
                        : widget.saved.add(q.id),
                  ),
                  icon: Icon(
                    widget.saved.contains(q.id)
                        ? Icons.star
                        : Icons.star_border,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 5),
            Text(
              q.text,
              style: const TextStyle(
                fontSize: 21,
                fontWeight: FontWeight.bold,
                height: 1.45,
              ),
            ),
            const SizedBox(height: 18),
            ...List.generate(
              q.options.length,
              (n) => Card(
                color: selected == n
                    ? const Color(0xFFE6FFFA)
                    : Colors.white,
                child: RadioListTile<int>(
                  value: n,
                  groupValue: selected,
                  onChanged: (v) => setState(() => selected = v),
                  title: Text(
                    q.options[n],
                    style: const TextStyle(fontSize: 16, height: 1.35),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 10),
            if (selected != null)
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: selected == q.answer
                      ? const Color(0xFFEFFCF5)
                      : const Color(0xFFFFF4F4),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Text(
                  selected == q.answer
                      ? '✅ برافو! الجواب صحيح.\n\n💡 علاش؟ ${q.explanation}'
                      : '❌ الجواب ماشي هو هادا.\n\n💡 الجواب الصحيح: ${q.options[q.answer]}\n\n${q.explanation}',
                  style: const TextStyle(fontSize: 15, height: 1.5),
                ),
              ),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: selected == null ? null : next,
              child: Text(
                i == qs.length - 1 ? 'شوف النتيجة' : 'السؤال الموالي',
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ResultPage extends StatelessWidget {
  final String title; final int score,total; final List<String> wrong; final bool exam;
  const ResultPage({super.key,required this.title,required this.score,required this.total,required this.wrong,required this.exam});
  @override
  Widget build(BuildContext c) {
    final pass = exam ? score >= 32 : score >= (total * .8).ceil();
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('النتيجة ديالك')),
        body: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            Center(
              child: Text(
                pass ? '🎉 برافو!' : '💪 عاود حاول!',
                style: const TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
            const SizedBox(height: 12),
            Center(
              child: Text(
                '$score / $total',
                style: const TextStyle(
                  fontSize: 56,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
            Center(
              child: Text(
                'النسبة: ${(score * 100 / total).round()}%',
                style: const TextStyle(fontSize: 19),
              ),
            ),
            const SizedBox(height: 18),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Text(
                  exam
                      ? (pass
                          ? 'دزتي المحاكاة بنجاح حسب عتبة 32/40.'
                          : 'ما وصلتيش لـ32/40. راجع الأخطاء ديالك وعاود جرّب.')
                      : (pass
                          ? 'مزيان! كمل بهاد الطريقة.'
                          : 'راجع هاد القسم وعاود التيست.'),
                  style: const TextStyle(fontSize: 17, height: 1.5),
                ),
              ),
            ),
            const SizedBox(height: 12),
            Card(
              child: ListTile(
                leading: const Icon(Icons.error_outline),
                title: const Text('الأسئلة اللي غلطتي فيهم'),
                trailing: Text(
                  '${wrong.length}',
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 18),
            FilledButton(
              onPressed: () => Navigator.pop(c),
              child: const Text('رجع للتعلم'),
            ),
          ],
        ),
      ),
    );
  }
}

class ReviewPage extends StatelessWidget {
  final String title; final Set<String> ids,saved,failed; final VoidCallback onChanged;
  const ReviewPage({super.key,required this.title,required this.ids,required this.saved,required this.failed,required this.onChanged});
  @override Widget build(BuildContext c){final list=allQuestions.where((q)=>ids.contains(q.id)).toList();return Directionality(textDirection:TextDirection.rtl,child:Scaffold(appBar:AppBar(title:Text(title)),body:list.isEmpty?const Center(child:Text('ما كاين حتى سؤال هنا دابا.')):ListView.builder(padding:const EdgeInsets.all(16),itemCount:list.length,itemBuilder:(_,i){final q=list[i];return Card(margin:const EdgeInsets.only(bottom:12),child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(q.category,style:const TextStyle(color:Color(0xFF0F766E),fontWeight:FontWeight.bold)),const SizedBox(height:7),Text(q.text,style:const TextStyle(fontSize:17,fontWeight:FontWeight.bold,height:1.4)),const SizedBox(height:10),Text('الجواب الصحيح: ${q.options[q.answer]}'),const SizedBox(height:7),Text('💡 ${q.explanation}',style:const TextStyle(color:Colors.black54,height:1.4)),Align(alignment:Alignment.centerLeft,child:IconButton(onPressed:(){if(saved.contains(q.id)){saved.remove(q.id);}else{saved.add(q.id);}onChanged();},icon:Icon(saved.contains(q.id)?Icons.star:Icons.star_border)))])));})));}
}

class SignsPage extends StatefulWidget { const SignsPage({super.key}); @override State<SignsPage> createState()=>_SignsPageState(); }
class _SignsPageState extends State<SignsPage> {
  String filter = 'الكل';

  @override
  Widget build(BuildContext c) {
    final groups = ['الكل', 'الخطر', 'المنع', 'الأسبقية', 'الإلزام', 'الخدمات'];
    final list = filter == 'الكل'
        ? signs
        : signs.where((s) => s.group == filter).toList();

    return Directionality(
      textDirection: TextDirection.rtl,
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text(
            'علامات التشوير 🚦',
            style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          const Text(
            'شوف العلامة، فهم شنو كتعني، وتعلم شنو خاصك تدير.',
            style: TextStyle(color: Colors.black54),
          ),
          const SizedBox(height: 12),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: groups
                  .map(
                    (g) => Padding(
                      padding: const EdgeInsets.only(left: 8),
                      child: ChoiceChip(
                        label: Text(g),
                        selected: filter == g,
                        onSelected: (_) => setState(() => filter = g),
                      ),
                    ),
                  )
                  .toList(),
            ),
          ),
          const SizedBox(height: 14),
          ...list.map(
            (s) => Card(
              child: ListTile(
                leading: SignIcon(symbol: s.symbol, group: s.group),
                title: Text(
                  s.title,
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: Text(s.meaning),
                onTap: () => showModalBottomSheet(
                  context: c,
                  builder: (_) => Directionality(
                    textDirection: TextDirection.rtl,
                    child: SafeArea(
                      child: Padding(
                        padding: const EdgeInsets.all(24),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              s.title,
                              style: const TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 12),
                            Text(
                              'شنو كتعني؟\n${s.meaning}',
                              style: const TextStyle(fontSize: 16, height: 1.5),
                            ),
                            const SizedBox(height: 10),
                            Text(
                              'شنو ندير؟\n${s.action}',
                              style: const TextStyle(fontSize: 16, height: 1.5),
                            ),
                            const SizedBox(height: 8),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
class SignIcon extends StatelessWidget{final String symbol,group;const SignIcon({super.key,required this.symbol,required this.group});@override Widget build(BuildContext c){final danger=group=='الخطر',prohibition=group=='المنع';return Container(width:54,height:54,alignment:Alignment.center,decoration:BoxDecoration(shape:BoxShape.circle,color:danger?Colors.orange.shade50:prohibition?Colors.red.shade50:Colors.blue.shade50,border:Border.all(color:danger?Colors.orange:prohibition?Colors.red:Colors.blue,width:3)),child:Text(symbol,style:const TextStyle(fontWeight:FontWeight.w900)));}}

class ProgressPage extends StatelessWidget {
  final int tests,best,attempted,correct; final Set<String> failed,saved; final VoidCallback onFailed,onSaved,onReset;
  const ProgressPage({super.key,required this.tests,required this.best,required this.attempted,required this.correct,required this.failed,required this.saved,required this.onFailed,required this.onSaved,required this.onReset});
  @override Widget build(BuildContext c){final accuracy=attempted==0?0:(correct*100/attempted).round();return Directionality(textDirection:TextDirection.rtl,child:ListView(padding:const EdgeInsets.all(20),children:[const Text('المستوى ديالك 📊',style:TextStyle(fontSize:27,fontWeight:FontWeight.bold)),const SizedBox(height:16),Row(children:[Expanded(child:_Metric(title:'التيستات',value:'$tests',icon:Icons.assignment_turned_in)),const SizedBox(width:10),Expanded(child:_Metric(title:'أحسن نتيجة',value:best==0?'—':'$best/40',icon:Icons.emoji_events))]),const SizedBox(height:10),Row(children:[Expanded(child:_Metric(title:'الأسئلة',value:'$attempted',icon:Icons.quiz)),const SizedBox(width:10),Expanded(child:_Metric(title:'الدقة',value:'$accuracy%',icon:Icons.gps_fixed))]),const SizedBox(height:12),Card(child:ListTile(onTap:onFailed,leading:const Icon(Icons.error_outline),title:const Text('الأخطاء ديالك'),trailing:Text('${failed.length}',style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold)))),Card(child:ListTile(onTap:onSaved,leading:const Icon(Icons.star_border),title:const Text('الأسئلة المحفوظة'),trailing:Text('${saved.length}',style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold)))),const SizedBox(height:20),const Text('ملاحظة',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),const SizedBox(height:8),const Text('هاد التطبيق للتعلم والتدريب. المعلومات القانونية خاصها ديما تتراجع مع المراجع المغربية الرسمية.',style:TextStyle(height:1.5,color:Colors.black54)),const SizedBox(height:24),OutlinedButton.icon(onPressed:()async{final ok=await showDialog<bool>(context:c,builder:(_)=>AlertDialog(title:const Text('تمسح المستوى؟'),content:const Text('غادي يتمسحو التيستات والأخطاء والمحفوظات ديالك.'),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('خليهوم')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('مسح'))]));if(ok==true)onReset();},icon:const Icon(Icons.delete_outline),label:const Text('مسح التقدم'))]));}
}
class _Metric extends StatelessWidget{final String title,value;final IconData icon;const _Metric({required this.title,required this.value,required this.icon});@override Widget build(BuildContext c)=>Card(child:Padding(padding:const EdgeInsets.all(15),child:Row(children:[CircleAvatar(child:Icon(icon)),const SizedBox(width:10),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(value,style:const TextStyle(fontSize:22,fontWeight:FontWeight.w900)),Text(title,style:const TextStyle(color:Colors.black54))]))])));}
